"""The real HTTP two-worker test with ONLY Linux-style LF report writing emulated.
This is a test monkeypatch, not a source change and not a Linux execution.
"""
from pathlib import Path
from unittest.mock import patch
import unittest
import two_workers_http_probes
original=Path.write_text

def linux_report_newline(self,data,encoding=None,errors=None,newline=None):
    if self.name=='report.json' and newline is None:
        newline='\n'
    return original(self,data,encoding=encoding,errors=errors,newline=newline)

print('SIMULATION: Windows host; only report.json text output forced to LF, emulating Linux newline.')
with patch.object(Path,'write_text',linux_report_newline):
    unittest.main(module=two_workers_http_probes,verbosity=2)
