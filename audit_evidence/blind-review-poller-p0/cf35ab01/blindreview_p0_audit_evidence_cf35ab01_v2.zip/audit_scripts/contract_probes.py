"""Test explicitly conflicting task/contract report metadata through Coordinator."""
import json,unittest
import audit_probes as fixture

class ContractProbes(unittest.TestCase):
    def test_wrong_task_and_contract_must_not_satisfy_quorum(self):
        f=fixture.PollerFaults(); f.setUp()
        for nid in ('5bao','9bao'):
            f.clients[nid].report_change={'task_id':'OTHER_TASK','contract_sha256':'f'*64}
        f.clients['rusty'].fixed_state='FAILED'
        c=f.runner(); outcome=c.step()
        print('CONFLICTING REPORTS observation:',json.dumps({'outcome':outcome,'accepted_nodes':c.state['accepted_nodes'],
          'requested_task':f.cfg['task_id'],'report_task':'OTHER_TASK','requested_contract':f.cfg['contract_sha256'][:8],
          'report_contract':'f'*8},ensure_ascii=False))
        self.assertNotEqual(outcome,'QUORUM_MET','reports carrying conflicting task and contract were counted')

if __name__=='__main__': unittest.main(verbosity=2)
