"""Read-only enforcement probe with a local fake harness, inside isolated scratch only."""
from pathlib import Path
import subprocess,unittest
import resource_probes as fixture

class WorkspaceTests(unittest.TestCase):
    def test_ignored_workspace_writes_must_not_pass_readonly_check(self):
        code=("import json,sys; from pathlib import Path; p=Path('.pytest_cache'); p.mkdir(exist_ok=True); "
              "(p/'audit-fixture.txt').write_text('sandbox test only'); print(Path.cwd()); "
              "Path(sys.argv[3]).write_text(json.dumps({'job_id':sys.argv[1],'commit_sha':sys.argv[2],"
              "'role':'blind-review','verdict':'APPROVE','summary':'fixture','findings':[]}))")
        result,output=fixture.ResourceProbes().run_worker(code)
        workspace=Path(output.decode('utf8').strip()); marker=workspace/'.pytest_cache'/'audit-fixture.txt'
        status=subprocess.check_output(['git','-C',str(workspace),'status','--porcelain','--untracked-files=all'],text=True)
        print('IGNORED WRITE observation:',{'file_created_in_ignored_dir':marker.is_file(),
                                            'git_status_empty':not status.strip(),'worker_state':result['state']})
        self.assertNotEqual(result['state'],'COMPLETED','untrusted harness modified ignored source path unnoticed')

if __name__=='__main__': unittest.main(verbosity=2)
