from pathlib import Path
import subprocess,time
root=Path(__file__).resolve().parent
repo=root/'source'
checks=[['git','-C',str(repo),'rev-parse','HEAD'],
        ['git','-C',str(repo),'status','--porcelain=v1','--untracked-files=all'],
        ['git','-C',str(repo),'fsck','--full']]
lines=[]
for cmd in checks:
    t=time.perf_counter(); result=subprocess.run(cmd,text=True,capture_output=True)
    lines.append('Command: '+' '.join(cmd)+'\nExit: '+str(result.returncode)+'\nSeconds: '+str(round(time.perf_counter()-t,3))+'\nstdout:\n'+result.stdout+'\nstderr:\n'+result.stderr+'\n')
log='\n'.join(lines)
(root/'evidence'/'final_git_verification.log').write_text(log,encoding='utf8')
print(log)
