"""Two real loopback Workers on one host, with a fake local reviewer; no external calls."""
from pathlib import Path
import json,os,subprocess,sys,tempfile,threading,time,unittest
from http.server import ThreadingHTTPServer
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
from blindreview.common import sha256_bytes
from blindreview.coordinator import Coordinator
from blindreview.http_client import ReviewClient
from blindreview.worker import Worker,ReviewHandler

class RealLocalTwoWorkers(unittest.TestCase):
    def test_same_host_two_ports_accepted_as_independent_seats(self):
        root=Path(tempfile.mkdtemp(prefix='real-http-',dir=BASE/'probe_data'))
        contract=root/'contract.md'; contract.write_text('Fixture contract',encoding='utf8')
        sha=subprocess.check_output(['git','-C',str(BASE/'source'),'rev-parse','HEAD'],text=True).strip()
        workers=[]; servers=[]; threads=[]; nodes=[]; token='{{SECRET_mh6g6hie}}'
        try:
            for nid in ('5bao','9bao'):
                config={'node_id':nid,'workdir':str(root/nid),'contract_path':str(contract),
                        'repositories':{'fixture':str(BASE/'source')},
                        'harnesses':{'fixture':{'command':[sys.executable,str(BASE/'source'/'tests'/'mock_reviewer.py'),
                                                           '{report_path}','{job_id}','{commit_sha}','{workspace}']}},
                        'max_job_seconds':20,'heartbeat_seconds':1,'max_concurrent':1}
                w=Worker(config); workers.append(w)
                handler=type('LocalHandler',(ReviewHandler,),{'worker':w,'token':token})
                server=ThreadingHTTPServer(('127.0.0.1',0),handler); servers.append(server)
                thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start(); threads.append(thread)
                nodes.append({'id':nid,'url':f'http://127.0.0.1:{server.server_port}',
                              'harness':'fixture','model':'fixture','token_env':'unused'})
            cfg={'task_id':'AUDIT','repository':'fixture','commit_sha':sha,
                 'contract_sha256':sha256_bytes(contract.read_bytes()),'nodes':nodes,
                 'overall_deadline_seconds':30,'poll_interval_seconds':1,'third_grace_seconds':3}
            c=Coordinator(cfg,root/'coord',client_factory=lambda n:ReviewClient(n['url'],token,timeout=2))
            c.initialize(); stop=time.monotonic()+20; outcome=None
            while time.monotonic()<stop and outcome is None:
                outcome=c.step()
                if outcome is None: time.sleep(.1)
            reports=[json.loads((root/'coord'/'reports'/f'{node["id"]}.json').read_text()) for node in nodes]
            same=all(reports[0][k]==reports[1][k] for k in reports[0] if k!='job_id')
            print(json.dumps({'physical_test_host_count':1,'controller_and_both_workers_pid':os.getpid(),
                              'loopback_ports':[s.server_port for s in servers],
                              'result':outcome,'accepted_nodes':c.state['accepted_nodes'],
                              'same_report_except_job_id':same,'report_summary':reports[0]['summary'],
                              'real_http':True,'real_sqlite':True,'real_git_clone':True,
                              'reviewer_is_mock':True},ensure_ascii=False))
            self.assertEqual(outcome,'QUORUM_MET'); self.assertEqual(len(c.state['accepted_nodes']),2)
            self.assertTrue(same)
        finally:
            for server in servers: server.shutdown(); server.server_close()
            for thread in threads: thread.join(timeout=3)
            for worker in workers:
                # The test waits for terminal jobs; shutdown sees no live model process.
                worker.shutdown(); worker.store.close()

if __name__=='__main__': unittest.main(verbosity=2)
