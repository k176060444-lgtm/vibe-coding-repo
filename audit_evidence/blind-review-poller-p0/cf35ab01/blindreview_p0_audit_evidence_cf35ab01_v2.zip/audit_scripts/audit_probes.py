"""Independent fault probes, all under the audit directory; no real remote nodes or models."""
from __future__ import annotations
import json, sqlite3, sys, tempfile, threading, time, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
from blindreview.common import ProtocolError, canonical_json, sha256_bytes, validate_report
from blindreview.coordinator import Coordinator
from blindreview.http_client import TransportError
from blindreview.store import JobStore

class Clock:
    def __init__(self): self.value=100000.0
    def __call__(self): return self.value
    def add(self,delta): self.value += delta

class Fake:
    def __init__(self,node,clock):
        self.node=node; self.clock=clock; self.job=None; self.finish=0; self.fixed_state=None
        self.cancel_count=0; self.verdict='APPROVE'; self.report_failures=0
        self.wrong_identity=False; self.wrong_job=False; self.report_change={}
        self.bad_hash=False; self.cancel_lost=False; self.status_advance=0
        self.transport_error=None
    def submit(self,job):
        self.job=job
        if self.transport_error: raise self.transport_error
        return self.status(job['job_id'])
    def _body(self):
        r={'job_id':self.job['job_id'],'role':'blind-review','commit_sha':self.job['commit_sha'],
           'verdict':self.verdict,'summary':'mock report','findings':[]}
        r.update(self.report_change); return r
    def status(self,job_id):
        if self.transport_error: raise self.transport_error
        self.clock.add(self.status_advance)
        state=self.fixed_state or ('COMPLETED' if self.clock()>=self.finish else 'RUNNING')
        b=self._body(); h=sha256_bytes((canonical_json(b)+'\n').encode())
        return {'node_id':'wrong' if self.wrong_identity else self.node,
                'job_id':'wrong-job' if self.wrong_job else job_id,'state':state,
                'result_sha256':h,'error':None}
    def report(self,job_id):
        if self.report_failures:
            self.report_failures-=1
            raise TransportError('injected report transport failure')
        r=self._body(); h=sha256_bytes((canonical_json(r)+'\n').encode())
        return {'node_id':self.node,'job_id':job_id,'report':r,'report_sha256':'0'*64 if self.bad_hash else h}
    def cancel(self,job_id):
        self.cancel_count+=1
        self.fixed_state='CANCELLED'
        if self.cancel_lost: raise TransportError('injected lost cancellation response')
        return {'node_id':self.node,'job_id':job_id,'state':'CANCELLED'}

class PollerFaults(unittest.TestCase):
    def setUp(self):
        self.tmp=Path(tempfile.mkdtemp(prefix='probe-',dir=ROOT/'probe_data'))
        self.clock=Clock()
        self.nodes=[{'id':n,'url':f'http://127.0.0.1:{18000+i}','harness':'codex',
                     'model':'fixture','token_env':'unused'} for i,n in enumerate(('5bao','9bao','rusty'))]
        self.cfg={'task_id':'T1','repository':'fixture','commit_sha':'a'*40,'contract_sha256':'b'*64,
                  'nodes':self.nodes,'poll_interval_seconds':60,'third_grace_seconds':600,
                  'overall_deadline_seconds':2400}
        self.clients={n['id']:Fake(n['id'],self.clock) for n in self.nodes}
    def runner(self):
        c=Coordinator(self.cfg,self.tmp,clock=self.clock,sleep=self.clock.add,
                      client_factory=lambda node:self.clients[node['id']]); c.initialize(); return c

    def test_01_all_three_completed(self):
        c=self.runner(); self.assertEqual(c.step(),'QUORUM_MET'); self.assertEqual(len(c.state['accepted_nodes']),3)
    def test_02_single_success_fails_at_deadline(self):
        self.clients['9bao'].finish=self.clock()+9999; self.clients['rusty'].finish=self.clock()+9999
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(2400)
        self.assertEqual(c.step(),'FAILED_QUORUM_TIMEOUT')
        self.assertFalse(c.state['result']=='QUORUM_MET')
    def test_03_two_success_599_and_600_seconds(self):
        self.clients['rusty'].finish=self.clock()+9999
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(599); self.assertIsNone(c.step())
        self.clock.add(1); self.assertEqual(c.step(),'QUORUM_MET'); self.assertEqual(self.clients['rusty'].cancel_count,1)
    def test_04_all_failed_terminates(self):
        for f in self.clients.values(): f.fixed_state='FAILED'
        c=self.runner(); self.assertEqual(c.step(),'FAILED_INSUFFICIENT_REVIEWERS')
    def test_05_simultaneous_completions(self):
        for f in self.clients.values(): f.finish=self.clock()+60
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(60)
        self.assertEqual(c.step(),'QUORUM_MET'); self.assertEqual(len(c.state['accepted_nodes']),3)
    def test_06_transport_failures_stay_nonterminal_until_deadline(self):
        for f in self.clients.values(): f.transport_error=TransportError('timeout / HTTP 500 / reset')
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(2400)
        self.assertEqual(c.step(),'FAILED_QUORUM_TIMEOUT')
    def test_07_running_after_421_seconds_is_not_failed(self):
        for f in self.clients.values(): f.finish=self.clock()+9999
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(421)
        self.assertIsNone(c.step()); self.assertEqual([j['state'] for j in c.state['jobs'].values()],['RUNNING']*3)
    def test_08_resume_preserves_deadline(self):
        self.clients['rusty'].finish=self.clock()+9999
        c=self.runner(); c.step(); deadline=c.state['quorum_at']; self.clock.add(601)
        resumed=Coordinator(self.cfg,self.tmp,clock=self.clock,sleep=self.clock.add,
                            client_factory=lambda n:self.clients[n['id']]); resumed.initialize(resume=True)
        self.assertEqual(resumed.state['quorum_at'],deadline); self.assertEqual(resumed.step(),'QUORUM_MET')
    def test_09_same_job_id_idempotence_and_conflict(self):
        s=JobStore(self.tmp/'test.sqlite'); j={'job_id':'j1','value':'x'}
        self.assertTrue(s.submit(j)[1]); self.assertFalse(s.submit(j)[1])
        with self.assertRaises(ProtocolError): s.submit({'job_id':'j1','value':'different'})
        s.close()
    def test_10_wrong_commit_is_rejected(self):
        self.clients['9bao'].report_change={'commit_sha':'f'*40}; self.clients['rusty'].fixed_state='FAILED'
        c=self.runner(); self.assertEqual(c.step(),'FAILED_INSUFFICIENT_REVIEWERS')
        self.assertFalse(c.state['jobs']['9bao']['valid'])
    def test_11_wrong_identity_and_job_are_rejected(self):
        self.clients['9bao'].wrong_identity=True; self.clients['rusty'].wrong_job=True
        c=self.runner(); self.assertIsNone(c.step()); self.assertFalse(c.state['jobs']['9bao']['valid']); self.assertFalse(c.state['jobs']['rusty']['valid'])
    def test_12_wrong_report_hash_rejected(self):
        self.clients['9bao'].bad_hash=True; self.clients['rusty'].fixed_state='FAILED'
        c=self.runner(); self.assertEqual(c.step(),'FAILED_INSUFFICIENT_REVIEWERS'); self.assertFalse(c.state['jobs']['9bao']['valid'])
    def test_13_wrong_report_task_and_contract_should_be_rejected(self):
        job={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review','task_id':'T1','contract_sha256':'b'*64}
        r={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review','verdict':'APPROVE','summary':'s','findings':[],
           'task_id':'WRONG','contract_sha256':'f'*64}
        with self.assertRaises(ProtocolError): validate_report(r,job)
    def test_14_malformed_verdict_should_be_protocol_error(self):
        job={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review'}
        report={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review','verdict':[], 'summary':'s','findings':[]}
        with self.assertRaises(ProtocolError): validate_report(report,job)
    def test_15_transient_fetch_errors_should_not_finalize(self):
        self.clients['9bao'].report_failures=1; self.clients['rusty'].report_failures=1
        c=self.runner(); result=c.step()
        self.assertIsNone(result,'two completed reports with transient retrieval errors should be retried')
        self.assertEqual(c.step(),'QUORUM_MET')
    def test_16_total_deadline_should_not_accept_late_third(self):
        self.cfg['overall_deadline_seconds']=300; self.clients['rusty'].finish=self.clock()+300
        c=self.runner(); self.assertIsNone(c.step()); self.clock.add(300)
        self.assertEqual(c.step(),'QUORUM_MET'); self.assertEqual(len(c.state['accepted_nodes']),2)
    def test_17_poll_sleep_must_not_overrun_600_seconds(self):
        self.cfg['poll_interval_seconds']=400; self.clients['rusty'].finish=self.clock()+9999
        c=self.runner(); start=self.clock(); self.assertEqual(c.run(),'QUORUM_MET')
        self.assertLessEqual(self.clock()-start,600,'grace period expired but fixed poll slept past deadline')
    def test_18_grace_config_over_600_should_be_rejected(self):
        self.cfg['third_grace_seconds']=1200
        with self.assertRaises(ValueError): self.runner()
    def test_19_quorum_clock_starts_when_second_is_accepted(self):
        self.clients['rusty'].finish=self.clock()+9999; self.clients['rusty'].status_advance=50
        c=self.runner(); start=self.clock(); self.assertIsNone(c.step())
        self.assertEqual(c.state['quorum_at'],start,'third status delayed quorum timestamp after second was accepted')
    def test_20_cancel_network_lost_then_reconciled(self):
        self.clients['rusty'].finish=self.clock()+9999; self.clients['rusty'].cancel_lost=True
        c=self.runner(); c.step(); self.clock.add(600); self.assertEqual(c.step(),'QUORUM_MET')
        self.assertTrue(c.state['jobs']['rusty']['cancel_requested'])
        self.clients['rusty'].cancel_lost=False
        self.assertEqual(c.reconcile_cancellations(),[])
        self.assertEqual(c.state['jobs']['rusty']['state'],'CANCELLED')
    def test_21_summary_should_reflect_reconciled_terminal_state(self):
        self.clients['rusty'].finish=self.clock()+9999; self.clients['rusty'].cancel_lost=True
        c=self.runner(); c.step(); self.clock.add(600); c.step(); self.clients['rusty'].cancel_lost=False
        c.reconcile_cancellations()
        summary=json.loads((self.tmp/'summary.json').read_text())
        self.assertEqual(summary['jobs']['rusty']['state'],'CANCELLED')
    def test_22_corrupt_state_resume_fails_closed(self):
        (self.tmp/'state.json').write_text('{bad',encoding='utf8')
        c=Coordinator(self.cfg,self.tmp,client_factory=lambda n:self.clients[n['id']])
        with self.assertRaises(ValueError): c.initialize(resume=True)
    def test_23_corrupt_sqlite_fails_closed(self):
        p=self.tmp/'corrupt.sqlite'; p.write_bytes(b'NOT A SQLITE DATABASE')
        with self.assertRaises(sqlite3.DatabaseError): JobStore(p)
    def test_24_interrupted_worker_not_automatically_resubmitted(self):
        s=JobStore(self.tmp/'journal.sqlite'); s.submit({'job_id':'j1'})
        s.transition('j1','RUNNING',expected=('QUEUED',)); s.set_pid('j1',12345); s.close()
        s=JobStore(self.tmp/'journal.sqlite'); self.assertEqual(s.recover(),['j1'])
        self.assertEqual(s.get('j1')['state'],'INTERRUPTED'); self.assertFalse(s.submit({'job_id':'j1'})[1]); s.close()
    def test_25_parallel_coordinators_must_not_initialize_twice(self):
        barrier=threading.Barrier(2); original=Coordinator._atomic_json; results=[]; errors=[]
        a=Coordinator(self.cfg,self.tmp,clock=self.clock,client_factory=lambda n:self.clients[n['id']])
        b=Coordinator(self.cfg,self.tmp,clock=self.clock,client_factory=lambda n:self.clients[n['id']])
        def gated(path,obj):
            if path.name=='state.json': barrier.wait(timeout=3)
            original(path,obj)
        def run(c):
            try: c.initialize(); results.append(c.state['run_id'])
            except Exception as e: errors.append(str(e))
        with patch.object(Coordinator,'_atomic_json',side_effect=gated):
            threads=[threading.Thread(target=run,args=(x,)) for x in (a,b)]
            [t.start() for t in threads]; [t.join(5) for t in threads]
        self.assertEqual(len(results),1,f'two initialized concurrently: run_ids={results}; errors={errors}')
    def test_26_request_changes_still_counts_as_formal_receipt(self):
        self.clients['5bao'].verdict='REQUEST_CHANGES'
        c=self.runner(); self.assertEqual(c.step(),'QUORUM_MET')
        self.assertEqual(c.state['jobs']['5bao']['verdict'],'REQUEST_CHANGES')
    def test_27_601_second_boundary_cancels(self):
        self.clients['rusty'].finish=self.clock()+9999
        c=self.runner(); c.step(); self.clock.add(601); self.assertEqual(c.step(),'QUORUM_MET')
        self.assertEqual(self.clients['rusty'].cancel_count,1)
    def test_28_model_and_harness_are_not_validated_against_matrix(self):
        # P1 task-level matrix is explicitly outside the project's stated P0 scope.
        self.nodes[0]['model']='arbitrary-but-syntactically-valid'
        c=self.runner(); self.assertEqual(c.state['jobs']['5bao']['request']['model'],'arbitrary-but-syntactically-valid')
    def test_29_finding_location_is_not_structurally_validated(self):
        job={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review'}
        r={'job_id':'j1','commit_sha':'a'*40,'role':'blind-review','verdict':'REQUEST_CHANGES',
           'summary':'s','findings':[{'severity':'BLOCKER','location':'not-a-file-or-line','description':'x'}]}
        self.assertEqual(validate_report(r,job),r)

if __name__=='__main__':
    (ROOT/'probe_data').mkdir(exist_ok=True)
    unittest.main(verbosity=2)
