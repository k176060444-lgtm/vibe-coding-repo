from pathlib import Path
import os, subprocess, sys, time
base=Path(__file__).resolve().parent
source=base/'source'
(base/'baseline_temp').mkdir(exist_ok=True)
(base/'empty_git_template').mkdir(exist_ok=True)
(base/'evidence').mkdir(exist_ok=True)
# Use only ordinary OS process bootstrap settings, never inherit API credentials.
keep={'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE'}
env={k:v for k,v in os.environ.items() if k.upper() in keep}
env.update({'PYTHONPATH':str(base/'baseline_hooks'), 'PYTHONPYCACHEPREFIX':str(base/'pycache'),
            'TEMP':str(base/'baseline_temp'),'TMP':str(base/'baseline_temp'),'TMPDIR':str(base/'baseline_temp'),
            'GIT_CONFIG_GLOBAL':'NUL','GIT_CONFIG_NOSYSTEM':'1','GIT_TEMPLATE_DIR':str(base/'empty_git_template'),
            'PYTHONUTF8':'1'})
commands=[('unittest',[sys.executable,'-m','unittest','discover','-s','tests','-v']),
          ('compileall',[sys.executable,'-m','compileall','-q','blindreview'])]
for name,command in commands:
    started=time.perf_counter()
    try:
        proc=subprocess.run(command,cwd=source,env=env,capture_output=True,text=True,timeout=55)
        elapsed=time.perf_counter()-started
        log=f'Command: python -m {" ".join(command[2:])}\nExit code: {proc.returncode}\nElapsed seconds: {elapsed:.3f}\n--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}'
    except subprocess.TimeoutExpired as exc:
        elapsed=time.perf_counter()-started
        log=f'Command timed out after {elapsed:.3f}s: {exc}'
    (base/'evidence'/f'baseline_{name}.log').write_text(log,encoding='utf-8')
    print(log,flush=True)
