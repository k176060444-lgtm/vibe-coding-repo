"""Controlled local crash/race probes. No real disk filling or process termination."""
import errno,json,sys,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
import audit_probes as audit_fixture
from blindreview.store import JobStore
from blindreview.coordinator import Coordinator

class RaceProbes(unittest.TestCase):
    def setUp(self):
        self.fixture=audit_fixture.PollerFaults(); self.fixture.setUp()
    def test_01_disk_full_during_receipt_preserves_same_job_id_on_resume(self):
        f=self.fixture
        f.clients['5bao'].finish=f.clock()+9999
        c=f.runner(); expected=c.state['jobs']['5bao']['request']['job_id']
        with patch('os.fsync',side_effect=OSError(errno.ENOSPC,'simulated disk full')):
            with self.assertRaises(OSError): c.step()
        disk=json.loads((f.tmp/'state.json').read_text())
        resumed=Coordinator(f.cfg,f.tmp,clock=f.clock,sleep=f.clock.add,
                            client_factory=lambda n:f.clients[n['id']]); resumed.initialize(resume=True)
        self.assertEqual(disk['jobs']['5bao']['state'],'NOT_SUBMITTED')
        self.assertEqual(resumed.state['jobs']['5bao']['request']['job_id'],expected)
        resumed.step()
        self.assertEqual(f.clients['5bao'].job['job_id'],expected)
        print('ENOSPC observation:',{'failure_propagated':True,'same_job_id_after_resume':True,
                                    'actual_disk_fill':False})
    def test_02_two_stores_can_both_claim_same_queued_job(self):
        db=self.fixture.tmp/'multi.sqlite'; a=JobStore(db); b=JobStore(db)
        a.submit({'job_id':'one'}); barrier=threading.Barrier(2); results=[]; errors=[]
        def wrap(original):
            def get(jid):
                row=original(jid); barrier.wait(timeout=4); return row
            return get
        a.get=wrap(a.get); b.get=wrap(b.get)
        def go(s):
            try: results.append(s.transition('one','RUNNING',expected=('QUEUED',)))
            except Exception as e: errors.append(repr(e))
        ts=[threading.Thread(target=go,args=(s,)) for s in (a,b)]
        [t.start() for t in ts]; [t.join(8) for t in ts]
        a.close(); b.close()
        print('TWO STORES observation:',{'transition_results':results,'errors':errors})
        self.assertEqual(sum(results),1,'two independent SQLite connections both claimed the same job')
    def test_03_late_completion_during_cancel_must_not_mark_valid(self):
        f=self.fixture; late=f.clients['rusty']; late.finish=f.clock()+9999
        c=f.runner(); c.step(); f.clock.add(600)
        def completed_during_cancel(job_id):
            late.cancel_count+=1; late.fixed_state='COMPLETED'; return late.status(job_id)
        late.cancel=completed_during_cancel
        self.assertEqual(c.step(),'QUORUM_MET')
        print('CANCEL RACE observation:',{'accepted_nodes':c.state['accepted_nodes'],
                                         'third_marked_valid':c.state['jobs']['rusty']['valid']})
        self.assertFalse(c.state['jobs']['rusty']['valid'],'late report accepted from cancellation response')

if __name__=='__main__': unittest.main(verbosity=2)
