"""Real local Worker probe; child exits by itself, no real model and no process kill."""
import json, subprocess, sys, tempfile, time, unittest
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
from blindreview.common import sha256_bytes
from blindreview.worker import Worker

class LocalWorkerProbes(unittest.TestCase):
    def test_stdin_block_defeats_hard_timeout_and_heartbeat(self):
        root=Path(tempfile.mkdtemp(prefix='stdin-worker-',dir=BASE/'probe_data'))
        contract=root/'contract.md'; contract.write_text('X'*300000,encoding='utf8')
        sha=subprocess.check_output(['git','-C',str(BASE/'source'),'rev-parse','HEAD'],text=True).strip()
        config={'node_id':'local-fixture','workdir':str(root/'work'),'contract_path':str(contract),
                'repositories':{'fixture':str(BASE/'source')},
                'harnesses':{'fixture':{'command':[sys.executable,'-c','import time; time.sleep(3.5)'],
                                        'stdin_prompt':True,'report_mode':'file'}},
                'max_job_seconds':1,'heartbeat_seconds':1,'max_concurrent':1,'clone_timeout_seconds':20}
        worker=Worker(config)
        request={'job_id':'stdin-block-probe','task_id':'T1','repository':'fixture','commit_sha':sha,
                 'role':'blind-review','harness':'fixture','model':'fixture','contract_sha256':sha256_bytes(contract.read_bytes())}
        start=time.monotonic(); worker.submit(request); pid_deadline=time.monotonic()+10
        while time.monotonic()<pid_deadline:
            current=worker.store.get(request['job_id'])
            if current['pid'] is not None or current['state'] in ('FAILED','TIMED_OUT','CANCELLED','COMPLETED'): break
            time.sleep(.05)
        if current['pid'] is None:
            print('SETUP FAILED:',json.dumps({'state':current['state'],'error':current['error']}))
            worker.store.close(); self.fail('test child never started')
        time.sleep(1.7)
        during=worker.store.get(request['job_id'])
        observed={'state_after_1_7s':during['state'],
                  'heartbeat_age_seconds':round(time.time()-during['heartbeat_at'],2),
                  'configured_hard_seconds':1}
        end=time.monotonic()+8
        while time.monotonic()<end:
            final=worker.store.get(request['job_id'])
            if final['state'] in ('FAILED','TIMED_OUT','CANCELLED','COMPLETED','INTERRUPTED'): break
            time.sleep(.05)
        observed['final_state']=final['state']; observed['final_error']=final['error']; observed['elapsed_seconds']=round(time.monotonic()-start,2)
        print('OBSERVED:',json.dumps(observed))
        if final['state'] not in ('FAILED','TIMED_OUT','CANCELLED','COMPLETED','INTERRUPTED'):
            self.fail('child did not exit on its own within test observation window')
        # Its child is already gone; shutdown has no process to terminate.
        worker.shutdown(); worker.store.close()
        self.assertNotEqual(during['state'],'RUNNING','blocking stdin.write bypassed hard timeout and heartbeat')

if __name__=='__main__': unittest.main(verbosity=2)
