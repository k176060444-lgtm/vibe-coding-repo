"""Read-only local CLI help/version; isolated home, no model calls or credentials."""
from pathlib import Path
import os, subprocess, sys, time
base=Path(__file__).resolve().parent
home=base/'cli_home'; app=home/'AppData'/'Roaming'; local=home/'AppData'/'Local'
for p in (home,app,local): p.mkdir(parents=True,exist_ok=True)
keep={'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE'}
env={k:v for k,v in os.environ.items() if k.upper() in keep}
env.update({'USERPROFILE':str(home),'APPDATA':str(app),'LOCALAPPDATA':str(local),'NO_COLOR':'1','CI':'1',
            'TEMP':str(base/'baseline_temp'),'TMP':str(base/'baseline_temp')})
commands=[('codex_version',['D:/codex/codex-agent.exe','--version']),
          ('codex_exec_help',['D:/codex/codex-agent.exe','exec','--help']),
          ('opencode_version',['D:/opencode/opencode.exe','--version']),
          ('opencode_run_help',['D:/opencode/opencode.exe','run','--help'])]
for name,cmd in commands:
    t=time.perf_counter()
    try:
        p=subprocess.run(cmd,cwd=base,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10)
        out=f'command={cmd}\nexit={p.returncode}; elapsed={time.perf_counter()-t:.3f}\nstdout:\n{p.stdout}\nstderr:\n{p.stderr}'
        print(name,'exit',p.returncode,'seconds',round(time.perf_counter()-t,3))
        if name.endswith('_version'): print('version:',p.stdout.strip())
        if name.endswith('_help'):
            for text in ('--sandbox','--model','--output-last-message','-C,','--agent','--format'):
                if text in p.stdout: print('  found',text)
    except subprocess.TimeoutExpired:
        out=f'{name} timed out after 10 seconds'; print(out)
    (base/'evidence'/(name+'.log')).write_text(out,encoding='utf8')
