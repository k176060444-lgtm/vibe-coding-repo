"""Follow-up fault probes informed by independent reviewers; all local synthetic data."""
from __future__ import annotations
import hashlib,json,os,subprocess,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
import audit_probes as fixture
import network_probes as network_fixture
from blindreview.common import sha256_bytes
from blindreview.coordinator import Coordinator
from blindreview.http_client import ReviewClient
from blindreview.worker import Worker

class Followup(unittest.TestCase):
    def setUp(self): self.root=Path(tempfile.mkdtemp(prefix='followup-',dir=BASE/'probe_data'))
    def worker_config(self,code,contract):
        return {'node_id':'local','workdir':str(self.root/'work'),'contract_path':str(contract),
                'repositories':{'fixture':str(BASE/'source')},
                'harnesses':{'fixture':{'command':[sys.executable,'-c',code,'{report_path}','{job_id}',
                                                   '{commit_sha}','{prompt_path}']}},
                'max_job_seconds':10,'heartbeat_seconds':1,'max_concurrent':1,'clone_timeout_seconds':20}
    def request(self,contract,job_id='followup'):
        sha=subprocess.check_output(['git','-C',str(BASE/'source'),'rev-parse','HEAD'],text=True).strip()
        return {'job_id':job_id,'task_id':'T1','repository':'fixture','commit_sha':sha,'role':'blind-review',
                'harness':'fixture','model':'fixture','contract_sha256':sha256_bytes(contract.read_bytes())}
    def await_job(self,w,jid,limit=15):
        end=time.monotonic()+limit
        while time.monotonic()<end:
            row=w.store.get(jid)
            if row['state'] in ('COMPLETED','FAILED','TIMED_OUT','CANCELLED','INTERRUPTED'): return row
            time.sleep(.03)
        self.fail('test job did not terminate in bounded observation window')
    def test_01_queued_job_restart_must_revalidate_contract(self):
        contract=self.root/'contract.md'; contract.write_text('CONTRACT_A',encoding='utf8')
        code=("import json,sys; from pathlib import Path; prompt=Path(sys.argv[4]).read_text(encoding='utf8'); "
              "Path(sys.argv[1]).write_text(json.dumps({'job_id':sys.argv[2],'commit_sha':sys.argv[3],"
              "'role':'blind-review','verdict':'APPROVE','summary':prompt[:10],'findings':[]}))")
        cfg=self.worker_config(code,contract); req=self.request(contract)
        with patch.object(Worker,'schedule',return_value=None):
            first=Worker(cfg); first.submit(req)
        self.assertEqual(first.store.get(req['job_id'])['state'],'QUEUED'); first.store.close()
        contract.write_text('CONTRACT_B',encoding='utf8')
        resumed=Worker(cfg); result=self.await_job(resumed,req['job_id'])
        report_path=self.root/'work'/'jobs'/req['job_id']/'report.json'
        summary=json.loads(report_path.read_text())['summary'] if report_path.exists() else None
        print('RECOVERY CONTRACT observation:',{'stored_request_contract':req['contract_sha256'][:10],
              'running_contract':resumed.contract_sha256[:10],'result':result['state'],'report_summary':summary})
        resumed.shutdown(); resumed.store.close()
        self.assertNotEqual(result['state'],'COMPLETED','queued request for contract A executed under B')
    def make_crashed_coordinator(self):
        f=fixture.PollerFaults(); f.setUp(); third=f.clients['rusty']; third.finish=f.clock()+99999
        real_submit=third.submit
        def crash(_job): raise SystemExit('injected process death after two persisted reports')
        third.submit=crash
        c=f.runner()
        with self.assertRaises(SystemExit): c.step()
        third.submit=real_submit
        state=json.loads((f.tmp/'state.json').read_text())
        self.assertEqual(sum(bool(j['valid']) for j in state['jobs'].values()),2)
        self.assertIsNone(state['quorum_at'])
        return f,state
    def test_02_crash_after_second_report_must_not_reset_grace(self):
        f,state=self.make_crashed_coordinator()
        accepted=max(j.get('accepted_at',0) for j in state['jobs'].values()); f.clock.add(601)
        c=Coordinator(f.cfg,f.tmp,clock=f.clock,sleep=f.clock.add,client_factory=lambda n:f.clients[n['id']])
        c.initialize(resume=True); result=c.step()
        print('CRASH GRACE observation:',{'second_accepted_at':accepted,'restored_quorum_at':c.state['quorum_at'],
                                           'reset_seconds':c.state['quorum_at']-accepted,'result':result})
        self.assertLessEqual(c.state['quorum_at']-accepted,0,'restart reset the third-seat grace timestamp')
    def test_03_two_persisted_reports_should_survive_total_deadline(self):
        f,state=self.make_crashed_coordinator(); f.clock.add(2401)
        c=Coordinator(f.cfg,f.tmp,clock=f.clock,sleep=f.clock.add,client_factory=lambda n:f.clients[n['id']])
        c.initialize(resume=True); result=c.step()
        print('CRASH DEADLINE observation:',{'persisted_valid_reports':2,'result':result})
        self.assertEqual(result,'QUORUM_MET','two reports received before crash were ignored after total deadline')
    def test_04_monitor_error_must_not_abandon_live_child(self):
        contract=self.root/'contract.md'; contract.write_text('fixture',encoding='utf8')
        code='import time; time.sleep(2.5)'
        cfg=self.worker_config(code,contract); req=self.request(contract)
        w=Worker(cfg); captured=[]; original=subprocess.Popen
        def track(*args,**kwargs):
            proc=original(*args,**kwargs)
            cmd=args[0] if args else kwargs.get('args',[])
            if isinstance(cmd,(list,tuple)) and len(cmd)>2 and cmd[1]=='-c' and cmd[2]==code: captured.append(proc)
            return proc
        with patch('blindreview.worker.subprocess.Popen',side_effect=track), \
             patch.object(w.store,'heartbeat',side_effect=OSError('injected heartbeat failure')):
            w.submit(req); result=self.await_job(w,req['job_id'])
        self.assertTrue(captured,'fixture child was not spawned')
        proc=captured[0]; alive=proc.poll() is None; tracked=req['job_id'] in w._running
        print('MONITOR ERROR observation:',{'job_state':result['state'],'child_alive_after_failed':alive,
                                             'child_still_tracked':tracked})
        if alive: proc.wait(timeout=5)  # wait for the 2.5s test child to exit naturally; do not kill it
        w.shutdown(); w.store.close()
        self.assertFalse(alive,'worker marked FAILED and lost track of a live child')
    def test_05_local_report_bytes_must_match_report_sha(self):
        f=fixture.PollerFaults(); f.setUp(); f.clients['rusty'].fixed_state='FAILED'
        c=f.runner(); self.assertEqual(c.step(),'QUORUM_MET')
        nid='5bao'; p=f.tmp/'reports'/f'{nid}.json'; raw=hashlib.sha256(p.read_bytes()).hexdigest()
        recorded=c.state['jobs'][nid]['report_sha256']
        print('REPORT FILE HASH observation:',{'raw_file_sha':raw,'recorded_sha':recorded,'same':raw==recorded})
        self.assertEqual(raw,recorded,'saved report bytes do not match stored report SHA256')
    def test_06_completed_resume_should_recheck_report_file(self):
        f=fixture.PollerFaults(); f.setUp(); f.clients['rusty'].fixed_state='FAILED'
        c=f.runner(); self.assertEqual(c.step(),'QUORUM_MET')
        p=f.tmp/'reports'/'5bao.json'; p.write_text('{"synthetic":"tampered"}',encoding='utf8')
        resumed=Coordinator(f.cfg,f.tmp,clock=f.clock,client_factory=lambda n:f.clients[n['id']]); resumed.initialize(resume=True)
        result=resumed.step()
        print('RESUME REPORT TAMPERING observation:',{'result':result,'synthetic_report_replaced':True})
        self.assertNotEqual(result,'QUORUM_MET','resume trusted result without verifying saved report')
    def test_07_http_timeout_should_bound_total_response_time(self):
        def response(h):
            h.send_response(200); h.end_headers()
            for _ in range(8): h.wfile.write(b' '); h.wfile.flush(); time.sleep(.07)
            h.wfile.write(b'{}'); h.wfile.flush()
        class Handler(network_fixture.BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self): response(self)
        srv=network_fixture.SingleServer(Handler)
        try:
            client=ReviewClient(f'http://127.0.0.1:{srv.port}','synthetic-local-token',timeout=.15)
            start=time.monotonic(); client.status('j1'); elapsed=time.monotonic()-start
            print('SLOW HTTP observation:',{'configured_seconds':.15,'elapsed_seconds':round(elapsed,3),
                                            'transport':'loopback with 0.07s chunk gaps'})
            self.assertLessEqual(elapsed,.3,'per-read timeout did not limit overall HTTP response')
        finally: srv.close()
    def test_08_capacity_should_not_spawn_unbounded_queued_threads(self):
        contract=self.root/'contract.md'; contract.write_text('fixture',encoding='utf8')
        w=Worker(self.worker_config('pass',contract)); base=self.request(contract)
        w._semaphore.acquire()
        try:
            for i in range(12): w.submit({**base,'job_id':f'queue-{i}'})
            queued=len(w._threads)
            print('QUEUE observation:',{'configured_capacity':w.capacity,'queued_threads':queued,
                                       'harness_children_launched':0})
        finally:
            w._stopping.set(); w._semaphore.release()
            threads=list(w._threads.values())
            for thread in threads: thread.join(timeout=3)
            w.store.close()
        self.assertLessEqual(queued,1,'one blocked thread was created per queued request')

if __name__=='__main__': unittest.main(verbosity=2)
