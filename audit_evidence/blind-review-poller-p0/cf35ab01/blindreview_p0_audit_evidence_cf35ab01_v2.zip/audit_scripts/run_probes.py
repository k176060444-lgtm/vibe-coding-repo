from pathlib import Path
import os, subprocess, sys, time
base=Path(__file__).resolve().parent
keep={'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE'}
env={k:v for k,v in os.environ.items() if k.upper() in keep}
env.update({'TEMP':str(base/'baseline_temp'),'TMP':str(base/'baseline_temp'),'TMPDIR':str(base/'baseline_temp'),
            'GIT_CONFIG_GLOBAL':'NUL','GIT_CONFIG_NOSYSTEM':'1','GIT_TEMPLATE_DIR':str(base/'empty_git_template'),
            'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'})
for script in sys.argv[1:]:
    path=base/script
    t=time.perf_counter()
    p=subprocess.run([sys.executable,'-B',str(path)],cwd=base,env=env,text=True,capture_output=True,timeout=45)
    log=f'Command: python -B {script}\nExit code: {p.returncode}\nElapsed seconds: {time.perf_counter()-t:.3f}\n--- stdout ---\n{p.stdout}\n--- stderr ---\n{p.stderr}'
    (base/'evidence'/(path.stem+'.log')).write_text(log,encoding='utf-8')
    print(log,flush=True)
