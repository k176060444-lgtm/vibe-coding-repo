"""Real local single-worker concurrent jobs and one-store duplicate-submit tests."""
import subprocess,sys,tempfile,time,threading,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
from blindreview.common import sha256_bytes
from blindreview.store import JobStore
from blindreview.worker import Worker

class ParallelTests(unittest.TestCase):
    def setUp(self): self.root=Path(tempfile.mkdtemp(prefix='parallel-',dir=BASE/'probe_data'))
    def test_parallel_duplicate_submissions_to_one_store(self):
        store=JobStore(self.root/'store.sqlite'); gate=threading.Barrier(8); result=[]; errors=[]
        def send():
            try: gate.wait(timeout=3); result.append(store.submit({'job_id':'same','value':'fixed'})[1])
            except Exception as exc: errors.append(repr(exc))
        threads=[threading.Thread(target=send) for _ in range(8)]
        [t.start() for t in threads]; [t.join(5) for t in threads]; store.close()
        print('SINGLE STORE concurrent submit:',{'created':sum(result),'existing':len(result)-sum(result),'errors':errors})
        self.assertEqual(len(result),8); self.assertEqual(sum(result),1); self.assertEqual(errors,[])
    def test_two_concurrent_jobs_same_worker_do_not_cross_results(self):
        contract=self.root/'contract.md'; contract.write_text('fixture',encoding='utf8')
        sha=subprocess.check_output(['git','-C',str(BASE/'source'),'rev-parse','HEAD'],text=True).strip()
        cfg={'node_id':'local','workdir':str(self.root/'work'),'contract_path':str(contract),
             'repositories':{'fixture':str(BASE/'source')},
             'harnesses':{'fixture':{'command':[sys.executable,str(BASE/'source'/'tests'/'mock_reviewer.py'),
                 '{report_path}','{job_id}','{commit_sha}','{workspace}','0.8']}},
             'max_concurrent':2,'max_job_seconds':10,'heartbeat_seconds':1,'clone_timeout_seconds':20}
        worker=Worker(cfg); jobs=['parallel-a','parallel-b']
        base={'task_id':'T1','repository':'fixture','commit_sha':sha,'role':'blind-review',
              'harness':'fixture','model':'fixture','contract_sha256':sha256_bytes(contract.read_bytes())}
        for jid in jobs: worker.submit({'job_id':jid,**base})
        both_running=False; end=time.monotonic()+15
        while time.monotonic()<end:
            results=[worker.store.get(j) for j in jobs]
            if all(r['state']=='RUNNING' for r in results): both_running=True
            if all(r['state'] in ('COMPLETED','FAILED','TIMED_OUT','CANCELLED') for r in results): break
            time.sleep(.04)
        states=[r['state'] for r in results]; hashes=[r['result_sha256'] for r in results]
        print('ONE WORKER concurrent jobs:',{'observed_simultaneous_running':both_running,'states':states,
                                              'distinct_job_ids':len(set(jobs))==2,'distinct_hashes':len(set(hashes))==2})
        if not all(s in ('COMPLETED','FAILED','TIMED_OUT','CANCELLED') for s in states):
            self.fail('fixture children not yet exited')
        worker.shutdown(); worker.store.close()
        self.assertTrue(both_running); self.assertEqual(states,['COMPLETED','COMPLETED']); self.assertEqual(len(set(hashes)),2)

if __name__=='__main__': unittest.main(verbosity=2)
