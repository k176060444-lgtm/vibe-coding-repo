"""Local-only HTTP fault probes. All tokens are synthetic."""
from __future__ import annotations
import http.client, json, socket, threading, time, unittest, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'source'))
from blindreview.http_client import ReviewClient, TransportError
from blindreview.worker import ReviewHandler

TOKEN='fake-audit-token-abcdefghijklmnopqrstuvwxyz'
class SingleServer:
    def __init__(self,handler):
        self.server=HTTPServer(('127.0.0.1',0),handler)
        self.port=self.server.server_port
        self.thread=threading.Thread(target=self.server.handle_request,daemon=True)
        self.thread.start()
    def close(self):
        self.thread.join(3); self.server.server_close()
        if self.thread.is_alive(): raise RuntimeError('HTTP handler did not finish')

class DummyStore:
    def get(self,job): return None
class DummyWorker:
    store=DummyStore()
    def submit(self,obj): return {},True

class NetworkTests(unittest.TestCase):
    def one(self,func):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self): func(self)
        return SingleServer(Handler)
    def client(self,s,timeout=1): return ReviewClient(f'http://127.0.0.1:{s.port}',TOKEN,timeout=timeout)
    def test_01_unauthorized_request_returns_401(self):
        h=type('LocalReviewHandler',(ReviewHandler,),{'worker':DummyWorker(),'token':TOKEN})
        s=SingleServer(h)
        try:
            with self.assertRaises(urllib.error.HTTPError) as caught:
                urllib.request.urlopen(f'http://127.0.0.1:{s.port}/v1/jobs/j1')
            self.assertEqual(caught.exception.code,401)
        finally: s.close()
    def test_02_large_request_body_rejected(self):
        h=type('LocalReviewHandler',(ReviewHandler,),{'worker':DummyWorker(),'token':TOKEN})
        s=SingleServer(h)
        try:
            req=urllib.request.Request(f'http://127.0.0.1:{s.port}/v1/jobs',data=b'x'*32769,
                                       headers={'Authorization':'Bearer '+TOKEN},method='POST')
            with self.assertRaises(urllib.error.HTTPError) as caught: urllib.request.urlopen(req)
            self.assertEqual(caught.exception.code,400)
        finally: s.close()
    def test_03_invalid_json_body_rejected(self):
        h=type('LocalReviewHandler',(ReviewHandler,),{'worker':DummyWorker(),'token':TOKEN})
        s=SingleServer(h)
        try:
            req=urllib.request.Request(f'http://127.0.0.1:{s.port}/v1/jobs',data=b'{oops',
                                       headers={'Authorization':'Bearer '+TOKEN},method='POST')
            with self.assertRaises(urllib.error.HTTPError) as caught: urllib.request.urlopen(req)
            self.assertEqual(caught.exception.code,400)
        finally: s.close()
    def test_04_http_500_is_transport_error(self):
        def handler(h): h.send_response(500); h.end_headers()
        s=self.one(handler)
        try:
            with self.assertRaises(TransportError): self.client(s).status('j1')
        finally: s.close()
    def test_05_invalid_json_is_transport_error(self):
        def handler(h): h.send_response(200); h.end_headers(); h.wfile.write(b'not json')
        s=self.one(handler)
        try:
            with self.assertRaises(TransportError): self.client(s).status('j1')
        finally: s.close()
    def test_06_refused_connection_is_transport_error(self):
        sock=socket.socket(); sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
        try:
            with self.assertRaises(TransportError): ReviewClient(f'http://127.0.0.1:{port}',TOKEN,timeout=.5).status('j1')
        finally: sock.close()
    def test_07_delayed_response_is_transport_error(self):
        def handler(h):
            time.sleep(.2)
            try: h.send_response(200); h.end_headers(); h.wfile.write(b'{}')
            except (BrokenPipeError,ConnectionResetError): pass
        s=self.one(handler)
        try:
            with self.assertRaises(TransportError): self.client(s,timeout=.03).status('j1')
        finally: s.close()
    def test_08_truncated_chunked_response_is_transport_error(self):
        def handler(h):
            h.send_response(200); h.send_header('Transfer-Encoding','chunked'); h.end_headers()
            h.wfile.write(b'10\r\nabc'); h.wfile.flush(); h.close_connection=True
        s=self.one(handler)
        try:
            with self.assertRaises(TransportError): self.client(s).status('j1')
        finally: s.close()
    def test_09_redirect_must_not_forward_token_to_different_origin(self):
        captured=[]
        def receiver(h):
            captured.append(bool(h.headers.get('Authorization')))
            h.send_response(200); h.end_headers(); h.wfile.write(b'{}')
        destination=self.one(receiver)
        def redirect(h):
            h.send_response(302); h.send_header('Location',f'http://127.0.0.1:{destination.port}/redirect-target'); h.end_headers()
        source=self.one(redirect)
        try:
            self.client(source).status('j1')
            self.assertEqual(captured,[False],'Authorization leaked to different host:port origin')
        finally:
            source.close(); destination.close()
    def test_10_invalid_utf8_should_return_400(self):
        h=type('LocalReviewHandler',(ReviewHandler,),{'worker':DummyWorker(),'token':TOKEN})
        s=SingleServer(h)
        try:
            req=urllib.request.Request(f'http://127.0.0.1:{s.port}/v1/jobs',data=b'\xff',
                                       headers={'Authorization':'Bearer '+TOKEN},method='POST')
            with self.assertRaises(urllib.error.HTTPError) as caught: urllib.request.urlopen(req)
            self.assertEqual(caught.exception.code,400)
        finally: s.close()
    def test_11_oversized_response_is_transport_error(self):
        def handler(h):
            h.send_response(200); h.end_headers()
            try: h.wfile.write(b'X'*(2*1024*1024+1))
            except (BrokenPipeError,ConnectionResetError): pass
        s=self.one(handler)
        try:
            with self.assertRaises(TransportError): self.client(s).status('j1')
        finally: s.close()

if __name__=='__main__': unittest.main(verbosity=2)
