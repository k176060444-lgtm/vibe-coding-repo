"""In-memory safety adaptation for the third-party audit baseline.
No production module or original repository test is changed.
"""
from pathlib import Path
import subprocess, tempfile, unittest

AUDIT = Path(__file__).resolve().parent.parent
SOURCE = AUDIT / 'source'
TEMP = AUDIT / 'baseline_temp'
TEMP.mkdir(exist_ok=True)
tempfile.tempdir = str(TEMP)
_original = unittest.TestLoader.loadTestsFromModule

def _load(self, module, *args, **kwargs):
    if module.__name__ == 'test_pipeline':
        def safe_make_repo(path):
            # Clone the existing inspected SHA, avoiding the test fixture's git commit.
            subprocess.run(['git', 'clone', '--quiet', '--no-checkout', str(SOURCE), str(path)], check=True)
            return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD']).decode().strip()
        module.make_repo = safe_make_repo
        method = module.WorkerIntegrationTest.test_cancel_running_review
        method.__unittest_skip__ = True
        method.__unittest_skip_why__ = 'would terminate a real child process; not authorized for this audit'
    return _original(self, module, *args, **kwargs)

unittest.TestLoader.loadTestsFromModule = _load
