"""Simulate a crash between final state save and summary file creation."""
import unittest
from unittest.mock import patch
import audit_probes as fixture
from blindreview.coordinator import Coordinator

class SummaryRecovery(unittest.TestCase):
    def test_resume_should_restore_missing_summary(self):
        f=fixture.PollerFaults(); f.setUp(); c=f.runner(); original=Coordinator._atomic_json
        def injected(path,value):
            if path.name=='summary.json': raise OSError('simulated summary write failure')
            return original(path,value)
        with patch.object(Coordinator,'_atomic_json',side_effect=injected):
            with self.assertRaises(OSError): c.step()
        resumed=Coordinator(f.cfg,f.tmp,clock=f.clock,client_factory=lambda node:f.clients[node['id']]); resumed.initialize(resume=True)
        result=resumed.step(); exists=(f.tmp/'summary.json').exists()
        print('MISSING SUMMARY observation:',{'resumed_result':result,'summary_exists':exists})
        self.assertTrue(exists,'resume returned a result without recreating summary')
if __name__=='__main__': unittest.main(verbosity=2)
