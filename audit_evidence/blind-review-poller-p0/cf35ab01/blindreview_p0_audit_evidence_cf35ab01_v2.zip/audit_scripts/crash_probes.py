"""Show malformed remote report can escape the real coordinator step."""
import unittest
import audit_probes as fixture
class CoordinatorCrash(unittest.TestCase):
    def test_malformed_verdict_must_not_crash_the_poller(self):
        f=fixture.PollerFaults(); f.setUp()
        f.clients['5bao'].report_change={'verdict':[]}
        c=f.runner()
        try:
            result=c.step()
        except Exception as exc:
            print('COORDINATOR observation:',{'exception_type':type(exc).__name__,'message':str(exc),
                                              'result':c.state['result']})
            self.fail('malformed report escaped Coordinator.step: '+type(exc).__name__)
        self.assertIsNone(result)
if __name__=='__main__': unittest.main(verbosity=2)
