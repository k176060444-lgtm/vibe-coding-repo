"""Real local Worker security/resource probes; subprocesses exit naturally."""
import os,subprocess,sys,tempfile,time,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source'))
from blindreview.common import sha256_bytes
from blindreview.worker import Worker

class ResourceProbes(unittest.TestCase):
    def run_worker(self,code,mode='file',max_log=100000):
        root=Path(tempfile.mkdtemp(prefix='resource-worker-',dir=BASE/'probe_data'))
        contract=root/'contract.md'; contract.write_text('fixture',encoding='utf8')
        sha=subprocess.check_output(['git','-C',str(BASE/'source'),'rev-parse','HEAD'],text=True).strip()
        config={'node_id':'local','workdir':str(root/'work'),'contract_path':str(contract),
                'repositories':{'fixture':str(BASE/'source')},
                'harnesses':{'fixture':{'command':[sys.executable,'-c',code,'{job_id}','{commit_sha}','{report_path}'],
                                        'report_mode':mode}},
                'max_job_seconds':10,'heartbeat_seconds':1,'max_log_bytes':max_log,'clone_timeout_seconds':20}
        worker=Worker(config)
        req={'job_id':'res-test','task_id':'T1','repository':'fixture','commit_sha':sha,'role':'blind-review',
             'harness':'fixture','model':'fixture','contract_sha256':sha256_bytes(contract.read_bytes())}
        worker.submit(req); deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            result=worker.store.get('res-test')
            if result['state'] in ('COMPLETED','FAILED','TIMED_OUT','CANCELLED','INTERRUPTED'): break
            time.sleep(.05)
        if result['state'] not in ('COMPLETED','FAILED','TIMED_OUT','CANCELLED','INTERRUPTED'):
            self.fail('fixture subprocess did not exit on its own')
        logfile=root/'work'/'jobs'/'res-test'/'execution.log'
        contents=logfile.read_bytes() if logfile.exists() else b''
        worker.shutdown(); worker.store.close()
        return result,contents
    def test_fast_exit_must_not_bypass_max_log_bytes(self):
        code=("import json,sys; print(json.dumps({'job_id':sys.argv[1], 'commit_sha':sys.argv[2], "
              "'role':'blind-review','verdict':'APPROVE','summary':'x'*2048,'findings':[]}))")
        result,content=self.run_worker(code,mode='stdout',max_log=128)
        print('FAST-OUTPUT observation:',{'state':result['state'],'bytes':len(content),'configured_max':128})
        self.assertEqual(result['state'],'FAILED','fast child output exceeded limit but was accepted')
    def test_synthetic_parent_token_is_inherited_and_recorded(self):
        marker='local-audit-fake-token-0123456789'
        os.environ['BLIND_AUDIT_SYNTHETIC_TOKEN']=marker
        code=("import os,json,sys; from pathlib import Path; "
              "print(os.environ.get('BLIND_AUDIT_SYNTHETIC_TOKEN','missing')); "
              "Path(sys.argv[3]).write_text(json.dumps({'job_id':sys.argv[1], 'commit_sha':sys.argv[2], "
              "'role':'blind-review','verdict':'APPROVE','summary':'fixture','findings':[]}))")
        result,content=self.run_worker(code)
        print('SYNTHETIC TOKEN observation:',{'child_inherited':marker.encode() in content,
                                             'plaintext_in_execution_log':marker.encode() in content,
                                             'state':result['state']})
        self.assertTrue(marker.encode() in content)
        self.assertEqual(result['state'],'COMPLETED')

if __name__=='__main__': unittest.main(verbosity=2)
