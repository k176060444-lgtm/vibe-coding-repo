"""Simulated clock: default 60s poll, 7s third-node response, no real wait."""
import unittest
import audit_probes as fixture
class DefaultTiming(unittest.TestCase):
    def test_default_poll_with_7_second_responses_must_respect_600_second_grace(self):
        f=fixture.PollerFaults(); f.setUp(); third=f.clients['rusty']
        third.finish=f.clock()+99999; third.status_advance=7
        c=f.runner(); result=c.run(); elapsed=f.clock()-c.state['quorum_at']
        print('DEFAULT TIMING observation:',{'result':result,'poll_seconds':60,
              'simulated_request_seconds':7,'elapsed_from_recorded_quorum_seconds':elapsed})
        self.assertLessEqual(elapsed,600)
if __name__=='__main__': unittest.main(verbosity=2)
