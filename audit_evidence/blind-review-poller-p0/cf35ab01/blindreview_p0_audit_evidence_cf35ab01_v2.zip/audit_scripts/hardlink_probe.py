"""Read-only Git hardlink identity and write-access test; writes zero object bytes."""
from pathlib import Path
import json,subprocess,tempfile,unittest
BASE=Path(__file__).resolve().parent
class GitCloneSafety(unittest.TestCase):
    def test_local_clone_objects_should_not_share_source_writable_inode(self):
        temp=Path(tempfile.mkdtemp(prefix='hardlink-readonly-',dir=BASE/'probe_data'))
        dst=temp/'clone'
        subprocess.run(['git','clone','--quiet','--no-checkout',str(BASE/'source'),str(dst)],check=True)
        source=BASE/'source'/'.git'/'objects'; clone=dst/'.git'/'objects'
        matches=[]
        for a in source.rglob('*'):
            if not a.is_file(): continue
            b=clone/a.relative_to(source)
            if not b.is_file(): continue
            x,y=a.stat(),b.stat()
            if x.st_ino and x.st_dev==y.st_dev and x.st_ino==y.st_ino:
                with b.open('r+b') as handle: writable=handle.writable()  # no write, seek, truncate, or content modification
                matches.append({'relative':str(a.relative_to(source)),'source_nlink':x.st_nlink,'writable_handle':writable})
        print('GIT HARDLINK observation:',json.dumps({'shared_objects':len(matches),'examples':matches[:3],
                                                       'bytes_written':0},ensure_ascii=False))
        self.assertFalse(matches,'local Git clone shares writable object files with its source')
if __name__=='__main__': unittest.main(verbosity=2)
