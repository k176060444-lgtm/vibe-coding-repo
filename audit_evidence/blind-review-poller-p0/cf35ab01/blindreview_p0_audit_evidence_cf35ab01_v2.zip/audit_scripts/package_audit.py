"""Bundle only audit-owned scripts, logs, tracked source snapshot, and synthetic evidence."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parent
out=root/'blindreview_p0_audit_evidence_cf35ab01_v2.zip'
items={}
items['blind-review-p0-audit-report.md']=(root/'blind-review-p0-audit-report.md').read_bytes()
for p in sorted(root.glob('*.py')):
    items['audit_scripts/'+p.name]=p.read_bytes()
items['audit_scripts/baseline_hooks/sitecustomize.py']=(root/'baseline_hooks'/'sitecustomize.py').read_bytes()
for p in sorted((root/'evidence').glob('*.log')):
    items['evidence/'+p.name]=p.read_bytes()
tracked=subprocess.check_output(['git','-C',str(root/'source'),'ls-files','-z']).decode().split('\0')
for rel in filter(None,tracked):
    items['baseline_source/'+rel]=(root/'source'/rel).read_bytes()
win=root/'probe_data'/'real-http-b25ohfky'
state=json.loads((win/'coord'/'state.json').read_text())
items['windows_hash_evidence/state.json']=(win/'coord'/'state.json').read_bytes()
items['windows_hash_evidence/summary.json']=(win/'coord'/'summary.json').read_bytes()
for nid,job in state['jobs'].items():
    items[f'windows_hash_evidence/{nid}-report.json']=(win/nid/'jobs'/job['request']['job_id']/'report.json').read_bytes()
manifest={'baseline_sha':'cf35ab01eae63298ff9f2ae9faa4d0012fe73c2c',
          'source_snapshot_has_git_metadata':False,
          'note':'Synthetic local fixtures only; Git checkout required under source/ to rerun scripts.',
          'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(items.items())}}
items['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf8')
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in sorted(items.items()): archive.writestr(name,data)
with zipfile.ZipFile(out) as archive:
    bad=archive.testzip()
    if bad is not None: raise RuntimeError(f'ZIP CRC failure: {bad}')
    count=len(archive.namelist())
digest=hashlib.sha256(out.read_bytes()).hexdigest()
print(json.dumps({'archive':str(out),'files':count,'bytes':out.stat().st_size,'sha256':digest,'zip_crc':'OK'},ensure_ascii=False))
