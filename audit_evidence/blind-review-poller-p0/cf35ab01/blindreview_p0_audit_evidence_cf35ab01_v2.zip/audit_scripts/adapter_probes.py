"""Mock CLI adapter fault probes; no real model calls."""
import unittest
import resource_probes as fixture

class AdapterProbes(unittest.TestCase):
    def test_codex_missing_report_is_failed(self):
        result,_=fixture.ResourceProbes().run_worker('pass',mode='file')
        print('MISSING REPORT:',{'state':result['state'],'error':result['error']})
        self.assertEqual(result['state'],'FAILED')
    def test_fenced_opencode_json_is_rejected_not_fabricated(self):
        code=("import json,sys; r={'job_id':sys.argv[1],'commit_sha':sys.argv[2],'role':'blind-review',"
              "'verdict':'APPROVE','summary':'fixture','findings':[]}; "
              "print(json.dumps({'type':'text','part':{'text':'```json\\n'+json.dumps(r)+'\\n```'}}))")
        result,_=fixture.ResourceProbes().run_worker(code,mode='opencode_jsonl')
        print('FENCED JSONL:',{'state':result['state'],'error':result['error']})
        self.assertEqual(result['state'],'FAILED')
    def test_invalid_stdout_json_is_failed(self):
        result,_=fixture.ResourceProbes().run_worker("print('malformed-not-json')",mode='stdout')
        print('MALFORMED STDOUT:',{'state':result['state'],'error':result['error']})
        self.assertEqual(result['state'],'FAILED')

if __name__=='__main__': unittest.main(verbosity=2)
