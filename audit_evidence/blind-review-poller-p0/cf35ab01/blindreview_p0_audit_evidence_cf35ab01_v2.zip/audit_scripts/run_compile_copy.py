from pathlib import Path
import hashlib, os, shutil, subprocess, sys, time
base=Path(__file__).resolve().parent
source=base/'source'/'blindreview'
dest=base/'compile_sandbox'/'blindreview'
shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
originals={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*.py')}
copies={p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*.py')}
assert originals==copies, 'Source copy mismatch'
keep={'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE'}
env={k:v for k,v in os.environ.items() if k.upper() in keep}
env['PYTHONUTF8']='1'
t=time.perf_counter()
p=subprocess.run([sys.executable,'-m','compileall','-q','blindreview'],cwd=dest.parent,env=env,capture_output=True,text=True)
log=f'Command: python -m compileall -q blindreview\nWorking dir: isolated source copy\nOriginal/copy Python source hashes: {len(originals)} matching\nExit: {p.returncode}\nElapsed seconds: {time.perf_counter()-t:.3f}\nstdout:\n{p.stdout}\nstderr:\n{p.stderr}'
(base/'evidence'/'compile_copy.log').write_text(log,encoding='utf-8')
print(log)
sys.exit(p.returncode)
